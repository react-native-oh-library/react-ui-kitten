/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */
/**
 * NOTICE: This file is copied from @react-native-oh-tpl/progress-bar-android and adapted.
 *
 * ProgressBarAndroid was initially part of the RN hence such copyright header is used.
 * This component was later extracted and moved to a separate library.
 * The copyright header above is also used in the react-native-community version, but the community version is converted to TypeScript.
 * @react-native-oh-tpl/progress-bar-android is based on from react-native-community and slightly adapted for OHOS.
 */

import React from "react";
import { ColorValue, StyleSheet, processColor } from "react-native";

import type { ViewProps } from "react-native/Libraries/Components/View/ViewPropTypes";
import RNProgressWheelNativeComponent from "../../../src/private/specs/components/ProgressWheelNativeComponent";
import RNProgressBarNativeComponent from "../../../src/private/specs/components/ProgressBarNativeComponent";

// #region types
/**
 * Style of the ProgressBar and whether it shows indeterminate progress (e.g. spinner).
 *
 * `indeterminate` can only be false if `styleAttr` is Horizontal, and requires a
 * `progress` value.
 */
type AnimatingStyle =
  | {
      styleAttr: "Horizontal";
      indeterminate: false;
      progress: number;
    }
  | {
      styleAttr:
        | "Horizontal"
        | "Normal"
        | "Small"
        | "Large"
        | "Inverse"
        | "SmallInverse"
        | "LargeInverse";
      // [RNOH] changed from RN declaration to include undefined,
      // since .defaultProps used to inject the default was deprecated.
      indeterminate?: true;
    };

export type ProgressBarAndroidProps = Readonly<
  ViewProps &
    AnimatingStyle & {
      /**
       * Whether to show the ProgressBar (true, the default) or hide it (false).
       */
      animating?: boolean;
      /**
       * Color of the progress bar.
       */
      color?: ColorValue;
      /**
       * Used to locate this view in end-to-end tests.
       */
      testID?: string;
    }
>;
// #endregion

const styleAttrToHeight = (styleAttr: AnimatingStyle["styleAttr"]) => {
  const attrHeight = {
    Horizontal: 16,
    Small: 16,
    SmallInverse: 16,
    Normal: 48,
    Inverse: 48,
    Large: 76,
    LargeInverse: 76,
  };
  return attrHeight[styleAttr] ?? 16;
};

/**
  * React component that wraps the Android-only `ProgressBar`. This component is
  * used to indicate that the app is loading or there is activity in the app.
  *
  * Example:
  *
  * ```
  * render: function() {
  *   var progressBar =
  *     <View style={styles.container}>
  *       <ProgressBar styleAttr="Inverse" />
  *     </View>;

  *   return (
  *     <MyLoadingComponent
  *       componentView={componentView}
  *       loadingView={progressBar}
  *       style={styles.loadingComponent}
  *     />
  *   );
  * },
  * ```
  */
const ProgressBarAndroid = React.forwardRef(
  (props: ProgressBarAndroidProps, forwardedRef) => {
    // set default values
    const {
      color = "#008577",
      style,
      styleAttr = "Normal",
      animating = true,
      testID
    } = props;

    const styleSheet = StyleSheet.create({
      progress: {
        height: styleAttrToHeight(styleAttr),
        width: "100%",
        display: animating ? undefined : "none",
      },
    });

    const processedColor = processColor(color);
    const commonProps = {
      // typechecking complains about `null` type missing from native component's color type spec without this check
      color: processedColor ?? undefined,
      style: [styleSheet.progress, style],
    };

    if (styleAttr == "Horizontal") {
      return (
        <RNProgressBarNativeComponent
          testID={testID}
          progress={props.indeterminate === false ? props.progress : undefined}
          indeterminate={props.indeterminate}
          {...commonProps}
          ref={forwardedRef as any}
        ></RNProgressBarNativeComponent>
      );
    }

    return (
      <RNProgressWheelNativeComponent
        testID={testID}
        {...commonProps}
        ref={forwardedRef as any}
      />
    );
  }
);

ProgressBarAndroid.displayName = "ProgressBarAndroid";

export default ProgressBarAndroid;
