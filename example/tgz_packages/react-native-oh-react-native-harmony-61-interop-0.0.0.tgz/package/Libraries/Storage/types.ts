/**
 * NOTICE: This file is copied from @react-native-oh-tpl/async-storage and adapted.
 *
 * AsyncStorage was initially part of React Native, which is why this copyright header is used.
 * It was later extracted and moved to a separate library.
 * @react-native-oh-tpl/async-storage is based on @react-native-async-storage/async-storage and has been slightly adapted for OHOS.
 */

export type ErrorLike = {
  message: string;
  key?: string;
};

export type Callback = (error?: Error | null) => void;

export type CallbackWithResult<T> = (
  error?: Error | null,
  result?: T | null
) => void;

export type KeyValuePair = [string, string | null];

export type MultiCallback = (errors?: readonly (Error | null)[] | null) => void;

export type MultiGetCallback = (
  errors?: readonly (Error | null)[] | null,
  result?: readonly KeyValuePair[]
) => void;

export type MultiRequest = {
  keys: readonly string[];
  callback?: MultiGetCallback;
  keyIndex: number;
  resolve?: (result: readonly KeyValuePair[]) => void;
  reject?: (error?: ErrorLike) => void;
};

export type AsyncStorageHook = {
  getItem: (callback?: CallbackWithResult<string>) => Promise<string | null>;
  setItem: (value: string, callback?: Callback) => Promise<null>;
  mergeItem: (value: string, callback?: Callback) => Promise<null>;
  removeItem: (callback?: Callback) => Promise<null>;
};
