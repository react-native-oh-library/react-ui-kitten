/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

import codegenNativeComponent from "react-native/Libraries/Utilities/codegenNativeComponent";
import { ProcessedColorValue, HostComponent, ViewProps } from "react-native";
import type {
  WithDefault,
  Double,
} from "react-native/Libraries/Types/CodegenTypes";

interface NativeProps extends ViewProps {
  progress?: Double;
  color?: ProcessedColorValue;
  indeterminate?: WithDefault<boolean, true>;
  testID?: string;
}

export default codegenNativeComponent<NativeProps>(
  "RNProgressBar"
) as HostComponent<NativeProps>;
