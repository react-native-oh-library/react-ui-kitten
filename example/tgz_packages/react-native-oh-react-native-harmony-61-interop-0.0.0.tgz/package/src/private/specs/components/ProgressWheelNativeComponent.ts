/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

import codegenNativeComponent from "react-native/Libraries/Utilities/codegenNativeComponent";
import { ProcessedColorValue, HostComponent, ViewProps } from "react-native";

interface NativeProps extends ViewProps {
  color?: ProcessedColorValue;
  testID?: string;
}

export default codegenNativeComponent<NativeProps>(
  "RNProgressWheel"
) as HostComponent<NativeProps>;
