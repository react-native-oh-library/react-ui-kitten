/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

import type { TurboModule } from "react-native";
import { TurboModuleRegistry } from "react-native";
import type { ErrorLike } from "../../../Libraries/Storage/types";

export interface Spec extends TurboModule {
  multiGet: (
    keys: string[],
    callback: (error?: ErrorLike[], result?: [string, string][]) => void
  ) => void;
  multiSet: (
    kvPairs: [string, string][],
    callback: (error?: ErrorLike[]) => void
  ) => void;
  multiRemove: (
    keys: readonly string[],
    callback: (error?: ErrorLike[]) => void
  ) => void;
  multiMerge: (
    kvPairs: [string, string][],
    callback: (error?: ErrorLike[]) => void
  ) => void;
  getAllKeys: (
    callback: (error?: ErrorLike[], result?: [string, string][]) => void
  ) => void;
  clear: (callback: (error?: ErrorLike[]) => void) => void;
}

export default TurboModuleRegistry.getEnforcing<Spec>("RNAsyncStorage");


